package modele;

/**
 * Created by utilisateur on 03/04/2019.
 */
public class DebitImpossibleException extends Exception {
    public DebitImpossibleException(String message) {
        super(message);
    }
}
