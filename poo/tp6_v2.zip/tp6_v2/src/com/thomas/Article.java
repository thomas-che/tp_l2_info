package com.thomas;

public class Article {
}
